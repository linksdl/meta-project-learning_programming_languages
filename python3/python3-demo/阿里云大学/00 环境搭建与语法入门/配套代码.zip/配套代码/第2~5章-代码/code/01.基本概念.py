print('hello','哈哈','abc')
print(123)
print('bcd')

a = 20
print(a)