

def test():
    print('test')